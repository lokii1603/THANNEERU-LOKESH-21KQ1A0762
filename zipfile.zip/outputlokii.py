Python 3.10.7 (tags/v3.10.7:6cc6b13, Sep  5 2022, 14:08:36) [MSC v.1933 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

================== RESTART: C:/Users/yeduk_lwurtbh/lokiipro.py =================
enter number of packages:20
enter the tourid:111
enter the source:hyd
enter the destination:goa
enter the days:5
enter the distance:450
enter the packagecost:20000
enter the tourid:222
enter the source:ong
enter the destination:pondicherry
enter the days:6
enter the distance:600
enter the packagecost:50000
enter the tourid:333
enter the source:hyd
enter the destination:delhi
enter the days:7
enter the distance:1200
enter the packagecost:55000
enter the tourid:444
enter the source:vij
enter the destination:mumbai
enter the days:6
enter the distance:800
enter the packagecost:33000
enter the tourid:555
enter the source:guntur
enter the destination:lucknow
enter the days:4
enter the distance:650
enter the packagecost:44000
enter the tourid:666
enter the source:chennai
enter the destination:mumbai
enter the days:8
enter the distance:704
enter the packagecost:66600
enter the tourid:777
enter the source:gujarat
enter the destination:kerala
enter the days:11
enter the distance:1122
enter the packagecost:85000
enter the tourid:888
enter the source:goa
enter the destination:kolkatta
enter the days:7
enter the distance:1210
enter the packagecost:67770
enter the tourid:999
enter the source:agra
enter the destination:hyd
enter the days:13
enter the distance:3900
enter the packagecost:83770
enter the tourid:1000
enter the source:delhi
enter the destination:banglore
enter the days:9
enter the distance:2200
enter the packagecost:56786
enter the tourid:1111
enter the source:banglore
enter the destination:ong
enter the days:12
enter the distance:600
enter the packagecost:40000
enter the tourid:2222
enter the source:vij
enter the destination:araku
enter the days:3
enter the distance:4
enter the packagecost:32000
enter the tourid:3333
enter the source:hyd
enter the destination:jammu
enter the days:3020
enter the distance:3586
enter the packagecost:98643
enter the tourid:4444
enter the source:vizag
enter the destination:hyd
enter the days:5
enter the distance:600
enter the packagecost:20000
enter the tourid:5555
enter the source:delhi
enter the destination:kolakatta
enter the days:8
enter the distance:830
enter the packagecost:78644
enter the tourid:6666
enter the source:kerala
enter the destination:vizag
enter the days:6
enter the distance:896
enter the packagecost:65754
enter the tourid:7777
enter the source:manipur
enter the destination:delhi
enter the days:7
enter the distance:768
enter the packagecost:65477
enter the tourid:8888
enter the source:uttarpradesh
enter the destination:hyd
enter the days:9
enter the distance:756
enter the packagecost:85758
enter the tourid:9999
enter the source:rajasthan
enter the destination:warangal
enter the days:13
enter the distance:6799
enter the packagecost:89687
enter the tourid:2000
enter the source:sikkim
enter the destination:ong
enter the days:8
enter the distance:3980
enter the packagecost:75765
Tourid	source	destination	Days	Distance	Packagecost
{'tourid': 111, 'source': 'hyd', 'destination': 'goa', 'days': 5, 'distance': 450, 'packagecost': 20000}
{'tourid': 222, 'source': 'ong', 'destination': 'pondicherry', 'days': 6, 'distance': 600, 'packagecost': 50000}
{'tourid': 333, 'source': 'hyd', 'destination': 'delhi', 'days': 7, 'distance': 1200, 'packagecost': 55000}
{'tourid': 444, 'source': 'vij', 'destination': 'mumbai', 'days': 6, 'distance': 800, 'packagecost': 33000}
{'tourid': 555, 'source': 'guntur', 'destination': 'lucknow', 'days': 4, 'distance': 650, 'packagecost': 44000}
{'tourid': 666, 'source': 'chennai', 'destination': 'mumbai', 'days': 8, 'distance': 704, 'packagecost': 66600}
{'tourid': 777, 'source': 'gujarat', 'destination': 'kerala', 'days': 11, 'distance': 1122, 'packagecost': 85000}
{'tourid': 888, 'source': 'goa', 'destination': 'kolkatta', 'days': 7, 'distance': 1210, 'packagecost': 67770}
{'tourid': 999, 'source': 'agra', 'destination': 'hyd', 'days': 13, 'distance': 3900, 'packagecost': 83770}
{'tourid': 1000, 'source': 'delhi', 'destination': 'banglore', 'days': 9, 'distance': 2200, 'packagecost': 56786}
{'tourid': 1111, 'source': 'banglore', 'destination': 'ong', 'days': 12, 'distance': 600, 'packagecost': 40000}
{'tourid': 2222, 'source': 'vij', 'destination': 'araku', 'days': 3, 'distance': 4, 'packagecost': 32000}
{'tourid': 3333, 'source': 'hyd', 'destination': 'jammu', 'days': 3020, 'distance': 3586, 'packagecost': 98643}
{'tourid': 4444, 'source': 'vizag', 'destination': 'hyd', 'days': 5, 'distance': 600, 'packagecost': 20000}
{'tourid': 5555, 'source': 'delhi', 'destination': 'kolakatta', 'days': 8, 'distance': 830, 'packagecost': 78644}
{'tourid': 6666, 'source': 'kerala', 'destination': 'vizag', 'days': 6, 'distance': 896, 'packagecost': 65754}
{'tourid': 7777, 'source': 'manipur', 'destination': 'delhi', 'days': 7, 'distance': 768, 'packagecost': 65477}
{'tourid': 8888, 'source': 'uttarpradesh', 'destination': 'hyd', 'days': 9, 'distance': 756, 'packagecost': 85758}
{'tourid': 9999, 'source': 'rajasthan', 'destination': 'warangal', 'days': 13, 'distance': 6799, 'packagecost': 89687}
{'tourid': 2000, 'source': 'sikkim', 'destination': 'ong', 'days': 8, 'distance': 3980, 'packagecost': 75765}
enter tour id:4444
vizag hyd 5 600 20000
enter starting point:hyd
3
no.of days:8
10
enter the distance you require above :1000
8
30000 85000
range: 15
lowest cost: 111
lowest cost: 4444
